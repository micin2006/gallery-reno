<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Followers extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'users_id',
        'follow_id'
    ];

    protected $table = 'followers';

    public function User() {
        return $this->hasMany(User::class, 'follow_id', 'id');
        return $this->belongsTo(User::class, 'users_id', 'id');
    }
}
