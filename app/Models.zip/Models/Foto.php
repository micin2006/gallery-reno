<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Psy\TabCompletion\Matcher\FunctionsMatcher;

class Foto extends Model
{
    use HasFactory;
    protected $fillable = [
        'users_id',
        'album_id',
        'judul_foto',
        'deskripsi'
    ];
    protected $table = 'foto';

    public function User() {
        return $this->belongsTo(User::class, 'users_id', 'id');
    }
    public function Album() {
        return $this->belongsTo(Album::class, 'album_id', 'id');
    }
    public Function Like(){
        return $this->hasMany(Like::class, 'foto_id', 'id');
    }
    public function Komentar() {
        return $this->hasMany(Komentar::class, 'foto_id', 'id');
    }
}
